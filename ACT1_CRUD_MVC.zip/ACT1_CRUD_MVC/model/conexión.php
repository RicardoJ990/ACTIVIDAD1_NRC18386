<?php
$conexion=new mysqli("localhost","root","","act1_crud_mvc");
$conexion->set_charset("utf8"); 
?>